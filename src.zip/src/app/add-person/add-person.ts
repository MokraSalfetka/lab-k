import { Component } from '@angular/core';
import {RouterLink} from '@angular/router';

@Component({
  selector: 'app-add-person',
  imports: [
    RouterLink
  ],
  templateUrl: './add-person.html',
  styleUrl: './add-person.css',
})
export class AddPerson {

}
